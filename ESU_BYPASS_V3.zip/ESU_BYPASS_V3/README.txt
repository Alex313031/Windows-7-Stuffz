# Prerequisites:

1: Install KB4490628 https://catalog.update.microsoft.com/search.aspx?q=kb4490628
 - This is the 2019-03 Servicing Stack Update

2. Install KB4474419 https://catalog.update.microsoft.com/search.aspx?q=kb4474419
 - This is the SHA-1 Update

These are needed because as of 2019, their update servers now require SHA-1 signature verification.
All Official Windows 7 ISOs will NOT have these two updates, so you need to manually download and install
them for your correct architecture before you can get further updates.

3. Install ALL standardly available updates (until 2020-01). You will need to reboot several times during these,
and after each reboot, you should press "Check for Updates" again before installing more updates, otherwise
some superflous or non-applicable updates may be presented. (This is a bug in Windows Vista and 7; it is not harmful,
but causes these updates to fail. Pressing "Check for Updates" again forces it to check all currently installed updates
and re-evaluate them against the available ones on their server).

Now we can actually patch Windows to get free ESU updates. This will work even for Windows editions not officially supported
for the ESU program like Win 7 Ultimate and Win 7 Home Premium/Basic. Note that this will NOT work on Starter Edition.

# ESU Patching:

1. Install 1_KB4575903 for your architecture.
 - This is the ESU Licensing Preparation Package

2. Install 2_KB5017397 for your architecture.
 - This is the 2022-09 Servicing Stack Update

3. Run LiveOS-Setup.cmd from inside BypassESU-v12 and select option "1" (Full Install)

4. Reboot and press "Check for Updates" again. You can now get updates until 2023-01!

# Important Notice about the .NET 4 ESU Bypass

It has an incompatibility issue and may cause MSI or other programs to stop working properly.
Therefore, it is recommended to install it only when new .NET 4 updates are available, then remove it after installing the updates.

Info is from https://forums.mydigitallife.net/threads/bypass-windows-7-extended-security-updates-eligibility.80606/
