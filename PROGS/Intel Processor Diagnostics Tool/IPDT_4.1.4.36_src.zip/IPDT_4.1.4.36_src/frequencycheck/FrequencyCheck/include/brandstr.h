//..
//..Frequency Module ..
//..developed by GTS..
//..
//..Intel(R) Corporation (C) 2019
//..

//..
//..brandstr.h
//..

#ifndef __BRANDSTR_H
#define __BRANDSTR_H

#include <string>

class BrandString
{
private:
	std::string sBS;

public:
	std::string getCPUBrandString();
	void BrandStringLength();
	int iBrandLength;	

	//..dtor
	~BrandString();

static const int iBSmax = 48;
};

#endif //__BRANDSTR_H