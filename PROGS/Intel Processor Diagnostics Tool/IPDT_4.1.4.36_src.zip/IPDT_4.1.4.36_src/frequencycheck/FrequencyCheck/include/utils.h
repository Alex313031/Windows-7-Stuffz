
//..
//..Frequency Module ..
//..developed by GTS..
//..
//..Intel(R) Corporation (C) 2019
//..

//..
//..utils.h
//..

#ifndef __UTILS_H
#define __UTILS_H


#include <Windows.h>
#include <stdio.h>
#include <time.h>
#include <cstdint>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>


enum TextColor
{
	Red = 0,
	Green,
	Yellow
};

//FILE *fLogFile;

//int iCheckFile;
extern int iColorText;
extern int iLastSpaceFound;
extern bool bLastSpaceFound;
extern std::string sParsedFrequency;
extern tm t;


std::string ConvertInt2String(int number);
//std::string ToUpper(std::string sText);
void PrintColorMsg(std::string sMsg, TextColor iColor);
std::string ParseFrequency(int iLength, std::string sName);
bool CheckFloat(const std::string& s);
bool RemoveFile(std::string sFileName);
void WriteLogFileNoEndL(std::string sFileName, std::string sLineEntry);
void WriteLogFile(std::string sFileName, std::string sLineEntry);
void WriteLogFile(std::string sFileName, int iy);
void WriteLogFile(std::string sFileName, std::string  sMessage, int iy);
void WriteLogFile(std::string sFileName, std::string  sMessage, std::string sLineEntry);
std::string DateTime(std::string s, std::time_t tempTime);
bool CheckString(std::string s, std::string f);



#endif //__UTILS_H

