//..
//..Frequency Module ..
//..developed by GTS..
//..
//..Intel(R) Corporation (C) 2019
//..

//..
//..measurefreq.h
//..

#ifndef __MEASUREFREQ_H
#define __MEASUREFREQ_H

#include <ctime>
#include <iostream>
#include <iomanip>
#include <string>
#include <intrin.h>
#include <math.h>

class MeasureFrequency
{
private:

public:
	int y;
	int x; 
	int endLoop;	
	void wait_mils(long);
	double measuredFrequency(void);

	//..dtor
	~MeasureFrequency();
};

#endif //__MEASUREFREQ_H
