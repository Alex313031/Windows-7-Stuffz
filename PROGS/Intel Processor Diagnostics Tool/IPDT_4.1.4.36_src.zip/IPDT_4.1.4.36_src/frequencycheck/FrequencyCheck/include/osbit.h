//..
//..Frequency Module ..
//..developed by GTS..
//..
//..Intel(R) Corporation (C) 2019
//..

//..
//..osbit.h
//..

#ifndef __OSBIT_H
#define __OSBIT_H
//..
//..osbit build defines
//..

//#define __WIN_64__
#define __WIN_32__

#endif //__OSBIT_H

