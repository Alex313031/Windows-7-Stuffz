//..
//..Frequency Module ..
//..developed by GTS..
//..
//..Intel(R) Corporation (C) 2019
//..

//..
//..main.h
//..

#ifndef __MAIN_H
#define __MAIN_H

//..includes
#include <ctime>
//#include <chrono>
#include <csignal>
#include <iostream>
#include <iomanip>
#include <ostream>
#include <sstream>
#include <string>
#include <vector>

#include <intrin.h>
#include <string.h>

#include "..\include\osbit.h"
#include "..\include\utils.h"
#include "..\include\brandstr.h"
#include "..\include\measurefreq.h"


enum ReturnValueDef
{
	Success = 0,
	Fail,
	Indeterminate,
	NoCompare,
	InvalidArgs
	//ConfigMismatch
};

int igPassFailStatus = 0;  // Default with success
int iRun;
int iLT = 0;
int iColorText = 0;
int iOptionValid;
int iArgIndex;
int iPrintVersionFlag = 1;
int iSuccessFlag = 1;
int iNoCompare = 0;
int iSkipTest = 0;
float fLowTolArg = 0;
int iLastSpaceFound = 0;
bool bLastSpaceFound = false;
std::string sParsedFrequency = "";
std::string sTestModuleVersion = "";
std::time_t tStartTimer;
std::time_t tEndTimer;
std::time_t tTotalTime;
std::string sProcessorName = "";
std::string sExpectedFrequency = "";
int iBrandStringNull = 0;
float fExpFreq = 0;
float fDetFreq = 0;
float fLowTolerance = .05f;
float fHighTolerance = .05f;
double dMeasuredFrequency = 0;

//time_t tempTime;

static std::string sModuleResultsFile = "FrequencyCheck_Results.txt";;

//..prototypes
void SignalFun(int iSigNum);
void Init(void);
void ValidateArgs(int argc, char *argv[]);
void HelpMessage(void);
void OutputVersion(void);
void CleanUp(void);
void ResultsStatus(void);
//void WriteResultsFile(int, int);
void WriteResultsFile(int);
void CheckFrequencyResult(void);
void OutputVersion(void);


#endif //__MAIN_H
