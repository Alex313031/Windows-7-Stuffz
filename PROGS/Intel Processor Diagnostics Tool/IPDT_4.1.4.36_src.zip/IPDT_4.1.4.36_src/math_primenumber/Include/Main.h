#ifndef __GOLDMODULEMAIN_H
#define __GOLDMODULEMAIN_H

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <iostream>
#include <sstream>
#include <list>
#include <csignal>
#include <chrono>
#include <thread>
#include <ctime>
#include <future>
#include <regex>

#include <iomanip>
#include <string>
#include <math.h>
#include <vector>
#include <cstdlib> // size_t
#include <cassert>


#include "../Include/OSDef.h"
#include "../Include/XMLParser.h"
#include "../Include/TextData.h"
#include "../Include/MDFUtil.h"
#include "../Include/GlobalConfig.h"
#include "GlobalDefs.h"
//#ifdef __WIN_OS__
//#include "DetectFeatures.h"
//#include <CL/cl_ext.h>
//#endif


//unsigned long int ulRetEAX = 0;
//unsigned long int ulRetEDX = 0;
//DWORD ulRetEAX = 0;
//DWORD ulRetEDX = 0;
unsigned long ulRetEAX = 0;
unsigned long ulRetEDX = 0;

XMLParser xd;


#define MPERF_APERF_FLAG		0x00000001
#define TRBOBST_FLAG			0x00000002

int y = 0;
int iSwirly = 0;
std::string sSwirly = "-\\|/";


// Declare config object
GlobalConfig gGlobalConfig;
TextData td;

//std::time_t tCurrentTime = std::time(nullptr);
std::time_t tStartTime;
std::time_t tEndTime;
std::time_t tTotalTime;

std::string sgGoldModuleResultsFile = "Math_PrimeNum_Results.txt";
int igPassFailStatus = 0;  // Default with success
int igPrintConfig = 0;
int igPauseApp = 0;
int iColorText = 0;
int iPrintVersionFlag = 1;
int iPrintSuccessFlag = 1;

std::string sgTestModuleVersion;  

int iOptionValid;
int iRun;
int iArgIndex;

// Prototypes
void Init(void);
void PrintSuccess(void);
void handleArgs(int argc, char *argv[]);
void PrintColorMsg(std::string sMsg, TextColor iColor);
void PauseWQuit(void);
void PrintVersion(void);
void SignalFun(int iSigNum);
void CleanUp(void);
void WriteResultsFile(int iPassFailStatus);
void HelpUseage(void);
bool is_integer(const std::string & s);
bool isOptionValid(int iArgLocal, int argcLocal, char *argvLocal[], VarType vt);

#endif  //__GLOBALCONFIG_H
