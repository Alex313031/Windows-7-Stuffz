
class DetectUtils
{
    
public:
    DetectUtils();
    void GetProcFamilyModel(int *CPUfamily, int *CPUmodel, int *CPUstepping);
    std::string getCPUBrandString();
    std::string getCPUmfg();
    void AVX();
    bool bCheckMMX();
    bool bCheckSSE();
    bool bCheckSSE2();
    bool bCheckSSE3();
    bool bCheckSSSE3();
    bool bCheckSSE4_1();
    bool bCheckSSE4_2();
    bool bCheckAES();
    bool bCheckPCLMULQDQ();
    bool bCheckAVX();
    bool bCheckAVX2();
    bool bCheckFMA3();
    bool bCheckAVX512BW();
    bool bCheckAVX512CD();
    bool bCheckAVX512DQ();
    bool bCheckAVX512ER();
    bool bCheckAVX512F();
    bool bCheckAVX512IFMA52();
    bool bCheckAVX512PF();
    bool bCheckAVX512VBMI();
    bool bCheckAVX512VL();
    bool isFeature_OS_Supported();
    int max_avx_supported();
    void getProcInfo();

};
