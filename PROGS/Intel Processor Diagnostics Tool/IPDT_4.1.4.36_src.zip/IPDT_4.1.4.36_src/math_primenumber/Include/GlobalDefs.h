#ifndef __GLOBALDEFS_H
#define __GLOBALDEFS_H



//..defines
#ifdef __WIN_OS__
#include <Windows.h>
#endif
#ifdef __LIN_OS__
#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include <ivec.h>
#include <fvec.h>
#include <dvec.h>
#include <math.h>
#include <string.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdlib.h>

#endif


//#include <CL/cl.h>

#include <pmmintrin.h>
#include <immintrin.h>



enum ReturnValueDef
{
	Success = 0,
	Fail,
	Indeterminate,
	NoCompare,
	InvalidArgs,
	ConfigMismatch
};

enum TextColor
{
	Red = 0,
	Green,
	Yellow
};

enum VarType
{
	vtINT = 0,
	vtSTRING
};


enum AVXLevelSupport
{
	AVX_Not_Supported = 0,
	AVX_Supported,
	AVX2_Supported,
	AVX512_Supported
};



enum FMA3Support
{
	FMA3_Not_Supported = 0,
	FMA3_Supported
};

enum IntelGraphicsSupport
{
	IG_Not_Supported = 0,
	IG_Supported
};


typedef unsigned __int64 UInt64;
typedef __int64 Int64;

#ifdef __WIN_OS__
typedef BOOL(WINAPI *PGNSI)(PULONGLONG);
#endif




#endif  //__GLOBALDEFS_H
