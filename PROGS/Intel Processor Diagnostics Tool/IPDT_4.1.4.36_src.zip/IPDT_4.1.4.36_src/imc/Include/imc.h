extern bool MSREnabled();
extern void wait ( int seconds );
extern bool GetIMCDetectedSpeed(unsigned long long *result);
extern bool GetIMCExpectedSpeed(unsigned long long *result);
extern bool GetMemorySize(long long *result);
extern void GetCPUFamilyModel(int *family, int *model);