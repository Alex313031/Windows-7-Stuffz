#ifndef __LOCALCONFIG_H
#define __LOCALCONFIG_H

// ---------------------------------------------------------------------------
//  Includes
// ---------------------------------------------------------------------------

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <sstream>
#include <list>

class LocalConfig
{


	// ---------------------------------------------------------------------------
	//  Public Vars
	// ---------------------------------------------------------------------------


	// ---------------------------------------------------------------------------
	// Include Project Version
	// ---------------------------------------------------------------------------



	// ---------------------------------------------------------------------------
	// LocalConfigItem
	// ---------------------------------------------------------------------------
	private: std::string _LocalConfigItem;
	public:  inline std::string getLocalConfigItem() const
	{
		return _LocalConfigItem;
	}
	public:  inline void setLocalConfigItem(const std::string newValue)
	{
		_LocalConfigItem = newValue;
	}


	// ---------------------------------------------------------------------------
	// FMS (Family Model Stepping) Family
	// ---------------------------------------------------------------------------
	private: std::string _FMS_family;
	public:  inline std::string getFMS_family() const
	{
		return _FMS_family;
	}
	public:  inline void setFMS_family(const std::string newValue)
	{
		_FMS_family = newValue;
	}

	// ---------------------------------------------------------------------------
	// FMS (Family Model Stepping) Model
	// ---------------------------------------------------------------------------
	private: std::string _FMS_model;
	public:  inline std::string getFMS_model() const
	{
		return _FMS_model;
	}
	public:  inline void setFMS_model(const std::string newValue)
	{
		_FMS_model = newValue;
	}

};  // LocalConfig

#endif  //__LOCALCONFIG_H
