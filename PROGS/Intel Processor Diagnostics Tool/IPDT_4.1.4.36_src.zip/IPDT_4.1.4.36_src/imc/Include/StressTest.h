#include "../Include/OSDef.h"

#ifdef __WIN_OS__
#include <ctime>
#endif
#ifdef __LIN_OS__
#include <sys/time.h>
#endif

class IMCStressTest
{	
private:
	void** p_lpvAddr;
	void** lpvAddr;
	unsigned long lockSize;
	int chunkAmount;
	long _startClock = 0L;
	int _endClock = 0;
	bool CheckTimeout(long endClock);
public:
	static unsigned long long GetFreeMemorySize();
	static bool SetProcessSize(int size);
	int Allocate(int chunkSize, int chunkTotal, bool NoCache);
	bool Test1Write();
	bool Test1Verify();
	bool Test2Write();
	bool Test2Verify();
	bool Test3Write();
	bool Test3Verify();
	bool Release();
};