/*
 * libudev - interface to udev device information
 *
 * Copyright (C) 2008-2009 Kay Sievers <kay.sievers@vrfy.org>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 */

#ifndef _LIBUDEV_H_
#define _LIBUDEV_H_

#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>

/*
 * udev - library context
 *
 * reads the udev config and system environment
 * allows custom logging
 */
extern "C"  struct udev;
extern "C"  struct udev *udev_ref(struct udev *udev);
extern "C"  void udev_unref(struct udev *udev);
extern "C"  struct udev *udev_new(void);
extern "C"  void udev_set_log_fn(struct udev *udev,
			    void (*log_fn)(struct udev *udev,
					   int priority, const char *file, int line, const char *fn,
					   const char *format, va_list args));
extern "C"  int udev_get_log_priority(struct udev *udev);
extern "C"  void udev_set_log_priority(struct udev *udev, int priority);
extern "C"  const char *udev_get_sys_path(struct udev *udev);
extern "C"  const char *udev_get_dev_path(struct udev *udev);
extern "C"  void *udev_get_userdata(struct udev *udev);
extern "C"  void udev_set_userdata(struct udev *udev, void *userdata);

/*
 * udev_list
 *
 * access to libudev generated lists
 */
extern "C"  struct udev_list_entry;
extern "C"  struct udev_list_entry *udev_list_entry_get_next(struct udev_list_entry *list_entry);
extern "C"  struct udev_list_entry *udev_list_entry_get_by_name(struct udev_list_entry *list_entry, const char *name);
extern "C"  const char *udev_list_entry_get_name(struct udev_list_entry *list_entry);
extern "C"  const char *udev_list_entry_get_value(struct udev_list_entry *list_entry);
/**
 * udev_list_entry_foreach:
 * @list_entry: entry to store the current position
 * @first_entry: first entry to start with
 *
 * Helper to iterate over all entries of a list.
 */
#define udev_list_entry_foreach(list_entry, first_entry) \
	for (list_entry = first_entry; \
	     list_entry != NULL; \
	     list_entry = udev_list_entry_get_next(list_entry))

/*
 * udev_device
 *
 * access to sysfs/kernel devices
 */
extern "C"  struct udev_device;
extern "C"  struct udev_device *udev_device_ref(struct udev_device *udev_device);
extern "C"  void udev_device_unref(struct udev_device *udev_device);
extern "C"  struct udev *udev_device_get_udev(struct udev_device *udev_device);
extern "C"  struct udev_device *udev_device_new_from_syspath(struct udev *udev, const char *syspath);
extern "C"  struct udev_device *udev_device_new_from_devnum(struct udev *udev, char type, dev_t devnum);
extern "C"  struct udev_device *udev_device_new_from_subsystem_sysname(struct udev *udev, const char *subsystem, const char *sysname);
/* udev_device_get_parent_*() does not take a reference on the returned device, it is automatically unref'd with the parent */
extern "C"  struct udev_device *udev_device_get_parent(struct udev_device *udev_device);
extern "C"  struct udev_device *udev_device_get_parent_with_subsystem_devtype(struct udev_device *udev_device,
								  const char *subsystem, const char *devtype);
/* retrieve device properties */
extern "C"  const char *udev_device_get_devpath(struct udev_device *udev_device);
extern "C"  const char *udev_device_get_subsystem(struct udev_device *udev_device);
extern "C"  const char *udev_device_get_devtype(struct udev_device *udev_device);
extern "C"  const char *udev_device_get_syspath(struct udev_device *udev_device);
extern "C"  const char *udev_device_get_sysname(struct udev_device *udev_device);
extern "C"  const char *udev_device_get_sysnum(struct udev_device *udev_device);
extern "C"  const char *udev_device_get_devnode(struct udev_device *udev_device);
extern "C"  struct udev_list_entry *udev_device_get_devlinks_list_entry(struct udev_device *udev_device);
extern "C"  struct udev_list_entry *udev_device_get_properties_list_entry(struct udev_device *udev_device);
extern "C"  const char *udev_device_get_property_value(struct udev_device *udev_device, const char *key);
extern "C"  const char *udev_device_get_driver(struct udev_device *udev_device);
extern "C"  dev_t udev_device_get_devnum(struct udev_device *udev_device);
extern "C"  const char *udev_device_get_action(struct udev_device *udev_device);
extern "C"  unsigned long long int udev_device_get_seqnum(struct udev_device *udev_device);
extern "C"  const char *udev_device_get_sysattr_value(struct udev_device *udev_device, const char *sysattr);

/*
 * udev_monitor
 *
 * access to kernel uevents and udev events
 */
extern "C"  struct udev_monitor;
extern "C"  struct udev_monitor *udev_monitor_ref(struct udev_monitor *udev_monitor);
extern "C"  void udev_monitor_unref(struct udev_monitor *udev_monitor);
extern "C"  struct udev *udev_monitor_get_udev(struct udev_monitor *udev_monitor);
/* kernel and udev generated events over netlink */
extern "C"  struct udev_monitor *udev_monitor_new_from_netlink(struct udev *udev, const char *name);
/* custom socket (use netlink and filters instead) */
extern "C"  struct udev_monitor *udev_monitor_new_from_socket(struct udev *udev, const char *socket_path);
/* bind socket */
extern "C"  int udev_monitor_enable_receiving(struct udev_monitor *udev_monitor);
extern "C"  int udev_monitor_get_fd(struct udev_monitor *udev_monitor);
extern "C"  struct udev_device *udev_monitor_receive_device(struct udev_monitor *udev_monitor);
/* in-kernel socket filters to select messages that get delivered to a listener */
extern "C"  int udev_monitor_filter_add_match_subsystem_devtype(struct udev_monitor *udev_monitor,
						    const char *subsystem, const char *devtype);
extern "C"  int udev_monitor_filter_update(struct udev_monitor *udev_monitor);
extern "C"  int udev_monitor_filter_remove(struct udev_monitor *udev_monitor);

/*
 * udev_enumerate
 *
 * search sysfs for specific devices and provide a sorted list
 */
extern "C"  struct udev_enumerate;
extern "C"  struct udev_enumerate *udev_enumerate_ref(struct udev_enumerate *udev_enumerate);
extern "C"  void udev_enumerate_unref(struct udev_enumerate *udev_enumerate);
extern "C"  struct udev *udev_enumerate_get_udev(struct udev_enumerate *udev_enumerate);
extern "C"  struct udev_enumerate *udev_enumerate_new(struct udev *udev);
/* device properties filter */
extern "C"  int udev_enumerate_add_match_subsystem(struct udev_enumerate *udev_enumerate, const char *subsystem);
extern "C"  int udev_enumerate_add_nomatch_subsystem(struct udev_enumerate *udev_enumerate, const char *subsystem);
extern "C"  int udev_enumerate_add_match_sysattr(struct udev_enumerate *udev_enumerate, const char *sysattr, const char *value);
extern "C"  int udev_enumerate_add_nomatch_sysattr(struct udev_enumerate *udev_enumerate, const char *sysattr, const char *value);
extern "C"  int udev_enumerate_add_match_property(struct udev_enumerate *udev_enumerate, const char *property, const char *value);
extern "C"  int udev_enumerate_add_syspath(struct udev_enumerate *udev_enumerate, const char *syspath);
/* run enumeration with active filters */
extern "C"  int udev_enumerate_scan_devices(struct udev_enumerate *udev_enumerate);
extern "C"  int udev_enumerate_scan_subsystems(struct udev_enumerate *udev_enumerate);
/* return device list */
extern "C"  struct udev_list_entry *udev_enumerate_get_list_entry(struct udev_enumerate *udev_enumerate);

/*
 * udev_queue
 *
 * access to the currently running udev events
 */
struct udev_queue;
struct udev_queue *udev_queue_ref(struct udev_queue *udev_queue);
void udev_queue_unref(struct udev_queue *udev_queue);
struct udev *udev_queue_get_udev(struct udev_queue *udev_queue);
struct udev_queue *udev_queue_new(struct udev *udev);
unsigned long long int udev_queue_get_kernel_seqnum(struct udev_queue *udev_queue);
unsigned long long int udev_queue_get_udev_seqnum(struct udev_queue *udev_queue);
int udev_queue_get_udev_is_active(struct udev_queue *udev_queue);
int udev_queue_get_queue_is_empty(struct udev_queue *udev_queue);
int udev_queue_get_seqnum_is_finished(struct udev_queue *udev_queue, unsigned long long int seqnum);
int udev_queue_get_seqnum_sequence_is_finished(struct udev_queue *udev_queue,
					       unsigned long long int start, unsigned long long int end);
struct udev_list_entry *udev_queue_get_queued_list_entry(struct udev_queue *udev_queue);
struct udev_list_entry *udev_queue_get_failed_list_entry(struct udev_queue *udev_queue);
#endif
