#ifndef MDFUTIL_H
#define MDFUTIL_H

//#include "OSDef.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <ctime>
#include <time.h>
#include <cctype>
#include <vector>
#include <functional>
#include <algorithm>
#include <iterator>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <io.h>


//#ifdef __WIN_OS__
//#include <io.h>
//#else
//#include <unistd.h>
//#endif


void CopyFile( std::string file1, std::string file2);
std::string DateTimeToString();
std::string ToUpper(std::string sText);
std::string compareStringParts(std::string& sStr1, std::string& sStr2, std::vector<std::string>& vDelStrList, bool bPrintStrings);
template<typename T> inline
void removeSubStrs(std::basic_string<T>& s, const std::basic_string<T>& p)
{
	typedef std::basic_string<T> container;
	typedef typename container::size_type size_type;
	
	size_type n = p.length();
	
	for (size_type i = s.find(p); i != std::string::npos; i = s.find(p))
		s.erase(i, n);
}
void split(const std::string& s, char c, std::vector<std::string>& v, bool bTrim);
void Tokenize(const std::string& str, std::vector<std::string>& tokens, const std::string& delimiters = " ");
void fnOpenFile(std::string sPath);
void fnCloseFile(void);
void SplitString(std::string sInput, std::vector<std::string>&  svOut, char cDelimiter);
std::string RemoveCharsFromString(std::string sInput, std::string sCharList);
std::string trim_right(const std::string &source , const std::string&  );
std::string trim_left( const std::string& source, const std::string& );
std::string trim(const std::string& source, const std::string& );
int fnWriteToFile(std::string sLineToWrite);
void Wait ( int seconds );
void WaitMils ( long mils );
std::string UtilConvert (int number, int numpad, char cFill);
std::string UtilConvert (float number);
std::string UtilConvert (int number);
std::string UtilConvert (long number);
std::string UtilConvert(double number);
int CustomAsciiToInteger(std::string sInput);
void GetProcFamilyModel(int *CPUfamily, int *CPUmodel, int *CPUstepping);


#endif //MDFUTIL_H
