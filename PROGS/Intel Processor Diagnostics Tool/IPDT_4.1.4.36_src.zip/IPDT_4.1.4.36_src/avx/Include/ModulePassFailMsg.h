#ifndef __MODULEPASSFAILMSG_H
#define __MODULEPASSFAILMSG_H

// ---------------------------------------------------------------------------
//  Includes
// ---------------------------------------------------------------------------
#include "OSDef.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <sstream>


class ModulePassFailMsg
{


//    // ---------------------------------------------------------------------------
//    //  Public Vars
//    // ---------------------------------------------------------------------------
//public:
//    std::string MessageCode;
//    std::string MessageStatus;
//    std::string MessageText;

    // ---------------------------------------------------------------------------
    //  MessageCode
    // ---------------------------------------------------------------------------
    private: std::string _MessageCode;
    public: inline std::string getMessageCode() const
    {
        return _MessageCode;
    }
    public: inline void setMessageCode(const std::string newValue)
    {
        _MessageCode = newValue;
    }

    // ---------------------------------------------------------------------------
    //  MessageStatus
    // ---------------------------------------------------------------------------
    private: std::string _MessageStatus;
    public:  inline std::string getMessageStatus() const
    {
        return _MessageStatus;
    }
    public:  inline void setMessageStatus(const std::string newValue)
    {
        _MessageStatus = newValue;
    }

    // ---------------------------------------------------------------------------
    //  MessageText
    // ---------------------------------------------------------------------------
    private: std::string _MessageText;
    public:  inline std::string getMessageText() const
    {
        return _MessageText;
    }
    public:  inline void setMessageText(const std::string newValue)
    {
        _MessageText = newValue;
    }



};  // ModulePassFailMsg


class ModulePassFail
{

    // ---------------------------------------------------------------------------
    //  ModuleName
    // ---------------------------------------------------------------------------
    private: std::string _ModuleName;
    public:  inline std::string getModuleName() const
    {
        return _ModuleName;
    }
    public:  inline void setModuleName(const std::string newValue)
    {
        _ModuleName = newValue;
    }

    // ---------------------------------------------------------------------------
    //  ModuleDateTime
    // ---------------------------------------------------------------------------
    private: std::string _ModuleDateTime;
    public:  inline std::string getModuleDateTime() const
    {
        return _ModuleDateTime;
    }
    public:  inline void setModuleDateTime(const std::string newValue)
    {
        _ModuleDateTime = newValue;
    }

    // ---------------------------------------------------------------------------
    //  ModuleVersion
    // ---------------------------------------------------------------------------
    private: std::string _ModuleVersion;
    public:  inline std::string getModuleVersion() const
    {
        return _ModuleVersion;
    }
    public:  inline void setModuleVersion(const std::string newValue)
    {
        _ModuleVersion = newValue;
    }





    // ---------------------------------------------------------------------------
    //  Public Vars
    // ---------------------------------------------------------------------------    

    // ---------------------------------------------------------------------------
    //  Message
    // ---------------------------------------------------------------------------    
    public: 
        ModulePassFailMsg Message;
    



};  
#endif  //__MODULEPASSFAILMSG_H