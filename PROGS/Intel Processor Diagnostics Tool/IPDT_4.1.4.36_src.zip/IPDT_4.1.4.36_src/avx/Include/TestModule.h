#pragma once

#include <iostream>
#include <sstream>
#include <regex>

class TestModule
{
public:
	TestModule();
	bool is_integer(const std::string & s);
	~TestModule();
};

