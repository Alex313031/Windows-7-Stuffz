#ifndef __GLOBALCONFIG_H
#define __GLOBALCONFIG_H

// ---------------------------------------------------------------------------
//  Includes
// ---------------------------------------------------------------------------

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <sstream>
#include <list>

class GlobalConfig
{


	// ---------------------------------------------------------------------------
	//  Public Vars
	// ---------------------------------------------------------------------------


	// ---------------------------------------------------------------------------
	// Include Project Version
	// ---------------------------------------------------------------------------



	// ---------------------------------------------------------------------------
	// GlobalConfigItem
	// ---------------------------------------------------------------------------
private: std::string _GlobalConfigItem;
public:  inline std::string getGlobalConfigItem() const
{
	return _GlobalConfigItem;
}
public:  inline void setGlobalConfigItem(const std::string newValue)
{
	_GlobalConfigItem = newValue;
}

		 // ---------------------------------------------------------------------------
		 // FMS (Family Model Stepping) Family
		 // ---------------------------------------------------------------------------
private: std::string _FMS_family;
public:  inline std::string getFMS_family() const
{
	return _FMS_family;
}
public:  inline void setFMS_family(const std::string newValue)
{
	_FMS_family = newValue;
}

		 // ---------------------------------------------------------------------------
		 // FMS (Family Model Stepping) Model
		 // ---------------------------------------------------------------------------
private: std::string _FMS_model;
public:  inline std::string getFMS_model() const
{
	return _FMS_model;
}
public:  inline void setFMS_model(const std::string newValue)
{
	_FMS_model = newValue;
}


		 // ---------------------------------------------------------------------------
		 // FMS (Family Model Stepping) Stepping
		 // ---------------------------------------------------------------------------
private: std::string _FMS_stepping;
public:  inline std::string getFMS_stepping() const
{
	return _FMS_stepping;
}
public:  inline void setFMS_stepping(const std::string newValue)
{
	_FMS_stepping = newValue;
}


		 // ---------------------------------------------------------------------------
		 //  DeviceID
		 // ---------------------------------------------------------------------------
private: std::string _QPIDeviceID;
public: inline std::string getQPIDeviceID() const
{
	return _QPIDeviceID;
}
public: inline void setQPIDeviceID(const std::string newValue)
{
	_QPIDeviceID = newValue;
}

		// ---------------------------------------------------------------------------
		//  RegValue
		// ---------------------------------------------------------------------------
private: std::string _QPIRegValue;
public: inline std::string getQPIRegValue() const
{
	return _QPIRegValue;
}
public: inline void setQPIRegValue(const std::string newValue)
{
	_QPIRegValue = newValue;
}

		// ---------------------------------------------------------------------------
		//  QPIRate
		// ---------------------------------------------------------------------------
private: std::string _QPIRate;
public: inline std::string getQPIRate() const
{
	return _QPIRate;
}
public: inline void setQPIRate(const std::string newValue)
{
	_QPIRate = newValue;
}


		// ---------------------------------------------------------------------------
		//  PCH 7 Series LPCDeviceID
		// ---------------------------------------------------------------------------
private: std::string _PCHS7_LPCDeviceID;
public: inline std::string getPCHS7_LPCDeviceID() const
{
	return _PCHS7_LPCDeviceID;
}
public: inline void setPCHS7_LPCDeviceID(const std::string newValue)
{
	_PCHS7_LPCDeviceID = newValue;
}

		// ---------------------------------------------------------------------------
		//  PCH 7 Series PCHName
		// ---------------------------------------------------------------------------
private: std::string _PCHS7_PCHName;
public: inline std::string getPCHS7_PCHName() const
{
	return _PCHS7_PCHName;
}
public: inline void setPCHS7_PCHName(const std::string newValue)
{
	_PCHS7_PCHName = newValue;
}



		// ---------------------------------------------------------------------------
		//  PCH 7 Series PCHNameDefault
		// ---------------------------------------------------------------------------
private: std::string _PCHS7_PCHNameDefault;
public: inline std::string getPCHS7_PCHNameDefault() const
{
	return _PCHS7_PCHNameDefault;
}
public: inline void setPCHS7_PCHNameDefault(const std::string newValue)
{
	_PCHS7_PCHNameDefault = newValue;
}


		// ---------------------------------------------------------------------------
		//  PCH 5 Series LPCDeviceID
		// ---------------------------------------------------------------------------
private: std::string _PCHS5_LPCDeviceID;
public: inline std::string getPCHS5_LPCDeviceID() const
{
	return _PCHS5_LPCDeviceID;
}
public: inline void setPCHS5_LPCDeviceID(const std::string newValue)
{
	_PCHS5_LPCDeviceID = newValue;
}

		// ---------------------------------------------------------------------------
		//  PCH 5 Series PCHName
		// ---------------------------------------------------------------------------
private: std::string _PCHS5_PCHName;
public: inline std::string getPCHS5_PCHName() const
{
	return _PCHS5_PCHName;
}
public: inline void setPCHS5_PCHName(const std::string newValue)
{
	_PCHS5_PCHName = newValue;
}

		// ---------------------------------------------------------------------------
		//  PCH 5 Series PCHNameDefault
		// ---------------------------------------------------------------------------
private: std::string _PCHS5_PCHNameDefault;
public: inline std::string getPCHS5_PCHNameDefault() const
{
	return _PCHS5_PCHNameDefault;
}
public: inline void setPCHS5_PCHNameDefault(const std::string newValue)
{
	_PCHS5_PCHNameDefault = newValue;
}


};  // GlobalConfig

#endif  //__GLOBALCONFIG_H
