#define __WIN_OS__
//#define __LIN_OS__
//#define __MAC_OS__

#define __WIN_64__
//#define __WIN_32__
//#define __LIN_64__
//#define __LIN_32__
