#ifndef EXTERNFUN_H
#define EXTERNFUN_H


#include <sstream>
#include <fstream>
#include <string>
#include <cstdlib>
#include "XMLParser.h"
//#include "IPDTConfig.h"

extern std::string sOJK;
extern std::string sGI;
extern std::string getCPUBrandString();
extern std::string getCPUmfg();
extern ModulePassFail * FreqencyTest(void);
extern unsigned long L2CacheTest(void);


#endif //EXTERNFUN_H