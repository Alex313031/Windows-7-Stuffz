#ifndef __DETECTFEATURES_H
#define __DETECTFEATURES_H
#define CL_USE_DEPRECATED_OPENCL_1_2_APIS


#include <string>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <cctype>
#include <limits>
#include <list>
#include <vector>
#include <functional>
#include <algorithm>
#include <iterator>


#include "ModulePassFailMsg.h"
#include "MDFUtil.h"
#include "OSDef.h"
#include "GlobalDefs.h"


/*
Note: MEMORYSTATUSEX struture means the following:
dwMemoryLoad = percent of memory in use
ullTotalPhys = Total Bytes of physical memory
ullAvailPhys = free  Bytes of physical memory
ullTotalPageFile = total Bytes of paging file
ullAvailPageFile = free Bytes of paging file
ullTotalVirtual = total Bytes of virtual memory
ullAvailVirtual = free  Bytes of virtual memory
ullAvailExtendedVirtual = free  Bytes of extended memory

// Divide by 1024 to convert bytes to KB

*/

//..
//..DetectFeatures Library ..
//..developed by GTS..
//..
//..Intel(R) Corporation (C) 2016


bool isFeature_OS_Supported();
AVXLevelSupport max_avx_supported();
FMA3Support fma3_supported();
ReturnValueDef CPUFeaturesSupported(gCPUSupportedFeatures &gf);
void initGraphics(gCPUSupportedFeatures &sf, cl_device_id &device);

#define ARRAY_SIZE 1024

#endif // __DETECTFEATURES_H