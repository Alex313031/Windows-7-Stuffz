#ifndef __GLOBALCONFIG_H
#define __GLOBALCONFIG_H

// ---------------------------------------------------------------------------
//  Includes
// ---------------------------------------------------------------------------

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <sstream>
#include <list>

class GlobalConfig
{


	// ---------------------------------------------------------------------------
	//  Public Vars
	// ---------------------------------------------------------------------------


	// ---------------------------------------------------------------------------
	// Include Project Version
	// ---------------------------------------------------------------------------



	// ---------------------------------------------------------------------------
	// GlobalConfigItem
	// ---------------------------------------------------------------------------
private: std::string _GlobalConfigItem;
public:  inline std::string getGlobalConfigItem() const
{
	return _GlobalConfigItem;
}
public:  inline void setGlobalConfigItem(const std::string newValue)
{
	_GlobalConfigItem = newValue;
}

		 // ---------------------------------------------------------------------------
		 // FMS (Family Model Stepping) Family
		 // ---------------------------------------------------------------------------
private: std::string _FMS_family;
public:  inline std::string getFMS_family() const
{
	return _FMS_family;
}
public:  inline void setFMS_family(const std::string newValue)
{
	_FMS_family = newValue;
}

		 // ---------------------------------------------------------------------------
		 // FMS (Family Model Stepping) Model
		 // ---------------------------------------------------------------------------
private: std::string _FMS_model;
public:  inline std::string getFMS_model() const
{
	return _FMS_model;
}
public:  inline void setFMS_model(const std::string newValue)
{
	_FMS_model = newValue;
}


		 // ---------------------------------------------------------------------------
		 // FMS (Family Model Stepping) Stepping
		 // ---------------------------------------------------------------------------
private: std::string _FMS_stepping;
public:  inline std::string getFMS_stepping() const
{
	return _FMS_stepping;
}
public:  inline void setFMS_stepping(const std::string newValue)
{
	_FMS_stepping = newValue;
}


		 // ---------------------------------------------------------------------------
		 // FMS (Family Model Stepping) CPUName
		 // ---------------------------------------------------------------------------
private: std::string _FMS_CPUName;
public:  inline std::string getFMS_CPUName() const
{
	return _FMS_CPUName;
}
public:  inline void setFMS_CPUName(const std::string newValue)
{
	_FMS_CPUName = newValue;
}

		 // ---------------------------------------------------------------------------
		 // FMS (Family Model Stepping) baseclock100
		 // ---------------------------------------------------------------------------
private: std::string _FMS_baseclock100;
public:  inline std::string getFMS_baseclock100() const
{
	return _FMS_baseclock100;
}
public:  inline void setFMS_baseclock100(const std::string newValue)
{
	_FMS_baseclock100 = newValue;
}

		


};  // GlobalConfig

#endif  //__GLOBALCONFIG_H
